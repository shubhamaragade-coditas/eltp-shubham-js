// Declare four variables without assigning values
let variable1;
let variable2;
let variable3;
let variable4;


// Declare four variables with assigned values

const city = "Goa";
const fruit = "Mango";
const rank = 24;
const cost = 22.5;


// Declare variables to store your first name, last name, marital status, country and age in multiple lines

const firstName1 = "Shubham";
const lastName1 = "Aragade";
const maritalStatus1 = "Single";
const country1 = "India";
const age1 = 22;

// Declare variables to store your first name, last name, marital status, country and age in a single line
const firstName = "Shubham", lastName = "Aragade", maritalStatus = "Single", country = "India", age = 22;


// Declare two variables myAge and yourAge and assign them initial values and log to the browser console.
const myAge = 22;
const yourAge = 21;
console.log("myAge: "+myAge);
console.log("yourAge: "+yourAge);